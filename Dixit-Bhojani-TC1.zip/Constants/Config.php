<?php

// Local DB Configuration
define("DB_HOST","localhost");
define("DB_USERNAME","root");
define("DB_PASSWORD","root");
define("DB_NAME","address-book");
define("DB_ADDRESSES_TABLENAME","Addresses");

?>